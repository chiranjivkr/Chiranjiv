from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import pickle
import pandas as pd
import json

app = Flask(__name__)
CORS(app)

# load model
model = pickle.load(open("model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

# load dataset
df = pd.read_csv("data.csv")
print(df.columns)
df = df[["name", "brand", "reviews.title", "reviews.text", "reviews.rating"]].dropna()

# 🏠 Home page - serve UI
@app.route("/")
def home():
    return send_file("UI.html")

# 🔮 Prediction API
@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.get_json()

        if not data or "text" not in data:
            return jsonify({"error": "No text provided"}), 400

        text = data["text"]

        transformed = vectorizer.transform([text])
        result = model.predict(transformed)[0]

        return jsonify({"prediction": result})

    except Exception as e:
        print("ERROR:", e)
        return jsonify({"error": "Server error"}), 500


# 📊 Get dataset reviews API
@app.route("/reviews", methods=["GET"])
def get_reviews():
    try:
        # ⚡ limit for performance
       return jsonify(df.to_dict(orient="records"))

    except Exception as e:
        print("ERROR:", e)
        return jsonify({"error": "Failed to load reviews"}), 500


# 📈 Get model metrics API
@app.route("/metrics", methods=["GET"])
def get_metrics():
    try:
        with open("metrics.json", "r") as f:
            metrics = json.load(f)
        return jsonify(metrics)
    except Exception as e:
        print("ERROR:", e)
        return jsonify({"error": "Failed to load metrics"}), 500

if __name__ == "__main__":
    print("Starting app...")
    app.run(debug=True)