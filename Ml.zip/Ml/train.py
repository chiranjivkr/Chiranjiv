import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
import pickle

# load dataset
df = pd.read_csv("data.csv")

# keep only needed columns
df = df[["reviews.text", "reviews.rating"]]

# remove null values
df = df.dropna()
df = df.sample(frac=1)

# convert rating to sentiment
def convert_label(rating):
    if rating >= 3:
        return "positive"
    else:
        return "negative"

df["label"] = df["reviews.rating"].apply(convert_label)

# Balance dataset to fix model predicting 'positive' for everything
pos_df = df[df["label"] == "positive"]
neg_df = df[df["label"] == "negative"]

if len(neg_df) > 0 and len(pos_df) > 0:
    # duplicate negative samples to match positive count
    neg_oversampled = neg_df.sample(len(pos_df), replace=True, random_state=42)
    df = pd.concat([pos_df, neg_oversampled]).sample(frac=1, random_state=42)

# features and labels
X = df["reviews.text"]
y = df["label"]

# split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# vectorization
vectorizer = CountVectorizer()
X_train_vectorized = vectorizer.fit_transform(X_train)
X_test_vectorized = vectorizer.transform(X_test)

# train model
model = MultinomialNB()
model.fit(X_train_vectorized, y_train)

import json

# evaluate model
y_pred = model.predict(X_test_vectorized)
acc = float(accuracy_score(y_test, y_pred))
cm = confusion_matrix(y_test, y_pred).tolist()

print(f"Accuracy: {acc:.4f}")
print("Confusion Matrix:")
print(cm)

# save metrics
metrics = {
    "accuracy": acc,
    "confusion_matrix": cm
}
with open("metrics.json", "w") as f:
    json.dump(metrics, f)

# save model
pickle.dump(model, open("model.pkl", "wb"))
pickle.dump(vectorizer, open("vectorizer.pkl", "wb"))

print("Model trained successfully!")