import { useState, useCallback } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { FileUpload } from '@/components/FileUpload';
import { CompressionResults } from '@/components/CompressionResults';
import { PDFCompressor } from '@/components/PDFCompressor';
import { FileIcon, Zap, Download, Trash2, FileText, FileImage, FileAudio, FileVideo, Settings } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CompressedFile {
  id: string;
  originalFile: File;
  compressedFile?: File;
  originalSize: number;
  compressedSize?: number;
  compressionRatio?: number;
  status: 'pending' | 'compressing' | 'completed' | 'error';
  progress: number;
  error?: string;
}

interface PDFCompressionSettings {
  quality: number;
  colorSpace: 'rgb' | 'grayscale' | 'monochrome';
  imageCompression: 'none' | 'low' | 'medium' | 'high';
  removeMetadata: boolean;
  optimizeForWeb: boolean;
}

export const CompressionApp = () => {
  const [files, setFiles] = useState<CompressedFile[]>([]);
  const [isCompressing, setIsCompressing] = useState(false);
  const [selectedPdfForSettings, setSelectedPdfForSettings] = useState<string | null>(null);
  const { toast } = useToast();

  const getFileTypeIcon = (type: string) => {
    if (type.startsWith('image/')) return FileImage;
    if (type.startsWith('audio/')) return FileAudio;
    if (type.startsWith('video/')) return FileVideo;
    if (type === 'application/pdf') return FileText;
    return FileIcon;
  };

  const getFileTypeBadge = (type: string) => {
    if (type.startsWith('image/')) return 'Image';
    if (type.startsWith('audio/')) return 'Audio';
    if (type.startsWith('video/')) return 'Video';
    if (type === 'application/pdf') return 'PDF';
    return 'Document';
  };

  const handleFilesSelected = useCallback((selectedFiles: File[]) => {
    const newFiles: CompressedFile[] = selectedFiles.map((file) => ({
      id: Math.random().toString(36).substr(2, 9),
      originalFile: file,
      originalSize: file.size,
      status: 'pending',
      progress: 0,
    }));

    setFiles(prev => [...prev, ...newFiles]);
  }, []);

  const simulateCompression = async (file: CompressedFile, pdfSettings?: PDFCompressionSettings): Promise<void> => {
    return new Promise((resolve) => {
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 20;
        if (progress >= 100) {
          clearInterval(interval);
          progress = 100;
          
          // Simulate compression results based on file type and settings
          let compressionRatio = 0.3 + Math.random() * 0.4; // 30-70% compression
          
          // PDF-specific compression calculation
          if (file.originalFile.type === 'application/pdf' && pdfSettings) {
            const qualityFactor = pdfSettings.quality / 100;
            const imageCompressionFactor = {
              none: 1,
              low: 0.9,
              medium: 0.7,
              high: 0.5,
            }[pdfSettings.imageCompression];
            
            const colorSpaceFactor = {
              rgb: 1,
              grayscale: 0.8,
              monochrome: 0.4,
            }[pdfSettings.colorSpace];

            compressionRatio = qualityFactor * imageCompressionFactor * colorSpaceFactor;
          }
          
          const compressedSize = Math.round(file.originalSize * compressionRatio);
          
          setFiles(prev => prev.map(f => 
            f.id === file.id 
              ? {
                  ...f,
                  status: 'completed' as const,
                  progress: 100,
                  compressedSize,
                  compressionRatio: ((file.originalSize - compressedSize) / file.originalSize) * 100,
                }
              : f
          ));
          
          resolve();
        } else {
          setFiles(prev => prev.map(f => 
            f.id === file.id 
              ? { ...f, progress: Math.round(progress) }
              : f
          ));
        }
      }, 200);
    });
  };

  const handleCompress = async () => {
    setIsCompressing(true);
    
    const pendingFiles = files.filter(f => f.status === 'pending');
    
    // Mark files as compressing
    setFiles(prev => prev.map(f => 
      f.status === 'pending' 
        ? { ...f, status: 'compressing' as const }
        : f
    ));

    // Compress files in parallel
    await Promise.all(
      pendingFiles.map(file => simulateCompression(file))
    );

    setIsCompressing(false);
    toast({
      title: "Compression Complete!",
      description: `Successfully compressed ${pendingFiles.length} file(s)`,
    });
  };

  const handlePDFCompress = async (file: File, settings: PDFCompressionSettings) => {
    const fileData = files.find(f => f.originalFile === file);
    if (!fileData) return;

    setFiles(prev => prev.map(f => 
      f.id === fileData.id 
        ? { ...f, status: 'compressing' as const }
        : f
    ));

    await simulateCompression(fileData, settings);
    setSelectedPdfForSettings(null);
    
    toast({
      title: "PDF Compression Complete!",
      description: `Successfully compressed ${file.name}`,
    });
  };

  const handleRemoveFile = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  const handleClearAll = () => {
    setFiles([]);
    setSelectedPdfForSettings(null);
  };

  const pendingFiles = files.filter(f => f.status === 'pending');
  const completedFiles = files.filter(f => f.status === 'completed');
  const pdfFiles = files.filter(f => f.originalFile.type === 'application/pdf');

  return (
    <div className="min-h-screen bg-gradient-secondary">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-primary rounded-2xl mb-6 animate-float">
            <Zap className="w-8 h-8 text-primary-foreground" />
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-4">
            Universal Compressor
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Compress images, audio, video, and PDF files with advanced algorithms. 
            Reduce file sizes while maintaining quality.
          </p>
        </div>

        {/* Upload Section */}
        <Card className="bg-card/80 backdrop-blur border-0 shadow-medium mb-8">
          <div className="p-8">
            <FileUpload onFilesSelected={handleFilesSelected} />
          </div>
        </Card>

        {/* PDF-specific compression settings */}
        {selectedPdfForSettings && (
          <div className="mb-8">
            {(() => {
              const file = files.find(f => f.id === selectedPdfForSettings);
              return file ? (
                <PDFCompressor 
                  file={file.originalFile} 
                  onCompress={handlePDFCompress}
                />
              ) : null;
            })()}
          </div>
        )}

        {/* Files List */}
        {files.length > 0 && (
          <Card className="bg-card/80 backdrop-blur border-0 shadow-medium mb-8">
            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-foreground">
                  Files ({files.length})
                </h3>
                <div className="flex gap-3">
                  {pendingFiles.length > 0 && (
                    <Button 
                      onClick={handleCompress}
                      disabled={isCompressing}
                      className="bg-gradient-primary hover:opacity-90 transition-opacity"
                    >
                      <Zap className="w-4 h-4 mr-2" />
                      {isCompressing ? 'Compressing...' : `Compress ${pendingFiles.length} file(s)`}
                    </Button>
                  )}
                  <Button 
                    variant="outline" 
                    onClick={handleClearAll}
                    className="border-border hover:bg-secondary"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear All
                  </Button>
                </div>
              </div>

              <div className="space-y-4">
                {files.map((file) => {
                  const FileTypeIcon = getFileTypeIcon(file.originalFile.type);
                  return (
                    <div 
                      key={file.id} 
                      className="flex items-center gap-4 p-4 rounded-lg bg-secondary/50 border border-border"
                    >
                      <div className="flex-shrink-0">
                        <FileTypeIcon className="w-8 h-8 text-muted-foreground" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium text-foreground truncate">
                            {file.originalFile.name}
                          </h4>
                          <Badge variant="outline">
                            {getFileTypeBadge(file.originalFile.type)}
                          </Badge>
                          <Badge variant={
                            file.status === 'completed' ? 'default' :
                            file.status === 'compressing' ? 'secondary' :
                            file.status === 'error' ? 'destructive' : 'outline'
                          }>
                            {file.status}
                          </Badge>
                        </div>
                        
                        <div className="text-sm text-muted-foreground mb-2">
                          Original: {(file.originalSize / 1024 / 1024).toFixed(2)} MB
                          {file.compressedSize && (
                            <span className="ml-4">
                              Compressed: {(file.compressedSize / 1024 / 1024).toFixed(2)} MB
                              <span className="text-primary ml-2 font-medium">
                                ({file.compressionRatio?.toFixed(1)}% reduction)
                              </span>
                            </span>
                          )}
                        </div>

                        {(file.status === 'compressing' || file.status === 'completed') && (
                          <Progress value={file.progress} className="h-2" />
                        )}
                      </div>

                      <div className="flex items-center gap-2">
                        {file.originalFile.type === 'application/pdf' && file.status === 'pending' && (
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => setSelectedPdfForSettings(file.id)}
                            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                          >
                            <Settings className="w-4 h-4 mr-1" />
                            PDF Settings
                          </Button>
                        )}
                        {file.status === 'completed' && (
                          <Button 
                            size="sm" 
                            variant="outline"
                            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                          >
                            <Download className="w-4 h-4 mr-1" />
                            Download
                          </Button>
                        )}
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => handleRemoveFile(file.id)}
                          className="text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </Card>
        )}

        {/* Results Summary */}
        {completedFiles.length > 0 && (
          <CompressionResults files={completedFiles} />
        )}
      </div>
    </div>
  );
};