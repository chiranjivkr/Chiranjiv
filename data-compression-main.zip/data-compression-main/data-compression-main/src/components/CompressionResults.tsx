import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Download, BarChart3, Zap } from 'lucide-react';

interface CompressedFile {
  id: string;
  originalFile: File;
  compressedFile?: File;
  originalSize: number;
  compressedSize?: number;
  compressionRatio?: number;
  status: 'pending' | 'compressing' | 'completed' | 'error';
  progress: number;
  error?: string;
}

interface CompressionResultsProps {
  files: CompressedFile[];
}

export const CompressionResults = ({ files }: CompressionResultsProps) => {
  const totalOriginalSize = files.reduce((sum, file) => sum + file.originalSize, 0);
  const totalCompressedSize = files.reduce((sum, file) => sum + (file.compressedSize || 0), 0);
  const totalSavings = totalOriginalSize - totalCompressedSize;
  const totalSavingsPercentage = (totalSavings / totalOriginalSize) * 100;

  const handleDownloadAll = () => {
    // In a real implementation, this would create a ZIP file with all compressed files
    console.log('Download all files');
  };

  return (
    <Card className="bg-gradient-accent border-0 shadow-medium">
      <div className="p-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center">
              <BarChart3 className="w-6 h-6 text-primary-foreground" />
            </div>
            <div>
              <h3 className="text-2xl font-semibold text-foreground">Compression Results</h3>
              <p className="text-muted-foreground">Your files have been successfully compressed</p>
            </div>
          </div>

          <Button 
            onClick={handleDownloadAll}
            className="bg-gradient-primary hover:opacity-90 transition-opacity"
          >
            <Download className="w-4 h-4 mr-2" />
            Download All
          </Button>
        </div>

        {/* Summary Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-card rounded-lg p-6 text-center border border-border shadow-soft">
            <div className="text-3xl font-bold text-foreground mb-2">
              {files.length}
            </div>
            <div className="text-sm text-muted-foreground">Files Compressed</div>
          </div>

          <div className="bg-card rounded-lg p-6 text-center border border-border shadow-soft">
            <div className="text-3xl font-bold text-foreground mb-2">
              {(totalOriginalSize / 1024 / 1024).toFixed(1)}
            </div>
            <div className="text-sm text-muted-foreground">MB Original</div>
          </div>

          <div className="bg-card rounded-lg p-6 text-center border border-border shadow-soft">
            <div className="text-3xl font-bold text-primary mb-2">
              {(totalCompressedSize / 1024 / 1024).toFixed(1)}
            </div>
            <div className="text-sm text-muted-foreground">MB Compressed</div>
          </div>

          <div className="bg-card rounded-lg p-6 text-center border border-border shadow-soft">
            <div className="text-3xl font-bold text-accent mb-2">
              {totalSavingsPercentage.toFixed(1)}%
            </div>
            <div className="text-sm text-muted-foreground">Space Saved</div>
          </div>
        </div>

        {/* Savings Highlight */}
        <div className="bg-gradient-primary rounded-xl p-6 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <Zap className="w-5 h-5 text-primary-foreground" />
            <span className="text-primary-foreground font-semibold">Total Savings</span>
          </div>
          <div className="text-2xl font-bold text-primary-foreground mb-1">
            {(totalSavings / 1024 / 1024).toFixed(1)} MB
          </div>
          <div className="text-primary-foreground/80">
            You've saved {totalSavingsPercentage.toFixed(1)}% of your original file size!
          </div>
        </div>
      </div>
    </Card>
  );
};