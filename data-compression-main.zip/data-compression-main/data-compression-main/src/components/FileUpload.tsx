import { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileImage, FileAudio, FileVideo, FileText, File as FileIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

interface FileUploadProps {
  onFilesSelected: (files: File[]) => void;
}

const getFileTypeIcon = (type: string) => {
  if (type.startsWith('image/')) return FileImage;
  if (type.startsWith('audio/')) return FileAudio;
  if (type.startsWith('video/')) return FileVideo;
  if (type === 'application/pdf') return FileText;
  return FileIcon;
};

const getFileTypeBadge = (type: string) => {
  if (type.startsWith('image/')) return 'Image';
  if (type.startsWith('audio/')) return 'Audio';
  if (type.startsWith('video/')) return 'Video';
  if (type === 'application/pdf') return 'PDF';
  return 'Document';
};

export const FileUpload = ({ onFilesSelected }: FileUploadProps) => {
  const [dragActive, setDragActive] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    onFilesSelected(acceptedFiles);
  }, [onFilesSelected]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.bmp'],
      'audio/*': ['.mp3', '.wav', '.aac', '.ogg', '.flac'],
      'video/*': ['.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm'],
      'application/pdf': ['.pdf'],
      'application/zip': ['.zip'],
      'application/x-rar-compressed': ['.rar'],
    },
    multiple: true,
    onDragEnter: () => setDragActive(true),
    onDragLeave: () => setDragActive(false),
  });

  return (
    <div className="w-full">
      <div
        {...getRootProps()}
        className={`
          border-2 border-dashed rounded-xl p-12 text-center cursor-pointer
          transition-all duration-300 ease-in-out
          ${isDragActive || dragActive 
            ? 'border-primary bg-gradient-accent animate-pulse-glow' 
            : 'border-border hover:border-primary hover:bg-gradient-accent/50'
          }
        `}
      >
        <input {...getInputProps()} />
        
        <div className="flex flex-col items-center justify-center space-y-6">
          <div className={`
            w-20 h-20 rounded-full bg-gradient-primary flex items-center justify-center
            transition-transform duration-300
            ${isDragActive ? 'scale-110' : 'hover:scale-105'}
          `}>
            <Upload className="w-10 h-10 text-primary-foreground" />
          </div>
          
          <div className="space-y-3">
            <h3 className="text-2xl font-semibold text-foreground">
              {isDragActive ? 'Drop files here!' : 'Drop files to compress'}
            </h3>
            <p className="text-muted-foreground max-w-md">
              Drag and drop your images, audio, or video files here, or click to browse.
              Supports multiple files.
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-2">
            <Badge variant="outline" className="border-primary text-primary">
              <FileImage className="w-3 h-3 mr-1" />
              Images
            </Badge>
            <Badge variant="outline" className="border-accent text-accent">
              <FileAudio className="w-3 h-3 mr-1" />
              Audio
            </Badge>
            <Badge variant="outline" className="border-secondary-foreground text-secondary-foreground">
              <FileVideo className="w-3 h-3 mr-1" />
              Video
            </Badge>
            <Badge variant="outline" className="border-destructive text-destructive">
              <FileText className="w-3 h-3 mr-1" />
              PDF
            </Badge>
          </div>

          <Button 
            variant="outline" 
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
          >
            Choose Files
          </Button>
        </div>
      </div>

      <div className="mt-6 text-center">
        <p className="text-sm text-muted-foreground">
          Supported formats: JPG, PNG, MP3, WAV, MP4, AVI, PDF, ZIP and more
        </p>
      </div>
    </div>
  );
};