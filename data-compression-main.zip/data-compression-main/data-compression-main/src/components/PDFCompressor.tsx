import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { FileText, Settings, Zap } from 'lucide-react';

interface PDFCompressionSettings {
  quality: number;
  colorSpace: 'rgb' | 'grayscale' | 'monochrome';
  imageCompression: 'none' | 'low' | 'medium' | 'high';
  removeMetadata: boolean;
  optimizeForWeb: boolean;
}

interface PDFCompressorProps {
  file: File;
  onCompress: (file: File, settings: PDFCompressionSettings) => void;
}

export const PDFCompressor = ({ file, onCompress }: PDFCompressorProps) => {
  const [settings, setSettings] = useState<PDFCompressionSettings>({
    quality: 80,
    colorSpace: 'rgb',
    imageCompression: 'medium',
    removeMetadata: true,
    optimizeForWeb: true,
  });

  const [showAdvanced, setShowAdvanced] = useState(false);

  const handleCompress = () => {
    onCompress(file, settings);
  };

  const getCompressionPreview = () => {
    const baseCompression = settings.quality / 100;
    const imageCompressionFactor = {
      none: 1,
      low: 0.9,
      medium: 0.7,
      high: 0.5,
    }[settings.imageCompression];
    
    const colorSpaceFactor = {
      rgb: 1,
      grayscale: 0.8,
      monochrome: 0.4,
    }[settings.colorSpace];

    const estimatedCompression = baseCompression * imageCompressionFactor * colorSpaceFactor;
    const estimatedSize = file.size * estimatedCompression;
    const savingsPercentage = ((file.size - estimatedSize) / file.size) * 100;

    return {
      estimatedSize,
      savingsPercentage,
    };
  };

  const preview = getCompressionPreview();

  return (
    <Card className="bg-card/80 backdrop-blur border-0 shadow-medium">
      <div className="p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-gradient-primary rounded-lg flex items-center justify-center">
            <FileText className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">PDF Compression Settings</h3>
            <p className="text-sm text-muted-foreground">{file.name}</p>
          </div>
        </div>

        {/* Quick Preset Buttons */}
        <div className="mb-6">
          <Label className="text-sm font-medium text-foreground mb-3 block">
            Quick Presets
          </Label>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSettings({
                quality: 95,
                colorSpace: 'rgb',
                imageCompression: 'low',
                removeMetadata: false,
                optimizeForWeb: false,
              })}
              className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
            >
              High Quality
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSettings({
                quality: 80,
                colorSpace: 'rgb',
                imageCompression: 'medium',
                removeMetadata: true,
                optimizeForWeb: true,
              })}
              className="border-accent text-accent hover:bg-accent hover:text-accent-foreground"
            >
              Balanced
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setSettings({
                quality: 60,
                colorSpace: 'grayscale',
                imageCompression: 'high',
                removeMetadata: true,
                optimizeForWeb: true,
              })}
              className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
            >
              Max Compression
            </Button>
          </div>
        </div>

        {/* Compression Quality */}
        <div className="mb-6">
          <Label className="text-sm font-medium text-foreground mb-3 block">
            Compression Quality: {settings.quality}%
          </Label>
          <Slider
            value={[settings.quality]}
            onValueChange={(value) => setSettings(prev => ({ ...prev, quality: value[0] }))}
            max={100}
            min={10}
            step={5}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span>Smaller size</span>
            <span>Better quality</span>
          </div>
        </div>

        {/* Advanced Settings Toggle */}
        <Button
          variant="ghost"
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="mb-4 p-0 h-auto text-primary hover:text-primary/80"
        >
          <Settings className="w-4 h-4 mr-2" />
          {showAdvanced ? 'Hide' : 'Show'} Advanced Settings
        </Button>

        {showAdvanced && (
          <div className="space-y-4 mb-6 p-4 bg-secondary/30 rounded-lg border border-border">
            {/* Color Space */}
            <div>
              <Label className="text-sm font-medium text-foreground mb-2 block">
                Color Space
              </Label>
              <Select 
                value={settings.colorSpace} 
                onValueChange={(value: PDFCompressionSettings['colorSpace']) => 
                  setSettings(prev => ({ ...prev, colorSpace: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rgb">RGB (Full Color)</SelectItem>
                  <SelectItem value="grayscale">Grayscale</SelectItem>
                  <SelectItem value="monochrome">Monochrome (B&W)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Image Compression */}
            <div>
              <Label className="text-sm font-medium text-foreground mb-2 block">
                Image Compression
              </Label>
              <Select 
                value={settings.imageCompression} 
                onValueChange={(value: PDFCompressionSettings['imageCompression']) => 
                  setSettings(prev => ({ ...prev, imageCompression: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        )}

        {/* Compression Preview */}
        <div className="bg-gradient-accent rounded-lg p-4 mb-6">
          <h4 className="font-semibold text-foreground mb-3">Compression Preview</h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <div className="text-muted-foreground">Original Size</div>
              <div className="font-medium text-foreground">
                {(file.size / 1024 / 1024).toFixed(2)} MB
              </div>
            </div>
            <div>
              <div className="text-muted-foreground">Estimated Size</div>
              <div className="font-medium text-primary">
                {(preview.estimatedSize / 1024 / 1024).toFixed(2)} MB
              </div>
            </div>
            <div className="col-span-2">
              <div className="text-muted-foreground">Space Savings</div>
              <div className="font-medium text-accent">
                {preview.savingsPercentage.toFixed(1)}% reduction
              </div>
            </div>
          </div>
        </div>

        {/* Compress Button */}
        <Button 
          onClick={handleCompress}
          className="w-full bg-gradient-primary hover:opacity-90 transition-opacity"
        >
          <Zap className="w-4 h-4 mr-2" />
          Compress PDF
        </Button>
      </div>
    </Card>
  );
};