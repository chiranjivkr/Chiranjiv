import { CompressionApp } from '@/components/CompressionApp';

const Index = () => {
  return <CompressionApp />;
};

export default Index;
