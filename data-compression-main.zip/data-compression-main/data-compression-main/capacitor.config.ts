import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.6609ede97873413eb085d68fe13aaac7',
  appName: 'data-compression',
  webDir: 'dist',
  server: {
    url: 'https://6609ede9-7873-413e-b085-d68fe13aaac7.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  bundledWebRuntime: false
};

export default config;